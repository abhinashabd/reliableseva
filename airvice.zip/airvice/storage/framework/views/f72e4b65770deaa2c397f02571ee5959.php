<script src="https://cdn.tailwindcss.com"></script>
<header class="bg-white shadow-md sticky top-0 z-50">
    <!-- Top Bar -->
    <div class="bg-blue-500 text-white py-2 text-sm hidden md:block" style="background-color: #153152">
        <div class="container mx-auto px-4 flex justify-between items-center">
            <div class="flex items-center space-x-6">
                <div class="flex items-center">
                    <svg class="w-4 h-4 mr-2 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path></svg>
                    <span>reliableseva@gmail.com</span>
                </div>
                <div class="flex items-center">
                    <svg class="w-4 h-4 mr-2 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path></svg>
                    <span>8882600406</span>
                </div>
            </div>
            <div class="flex items-center space-x-4">
                <span>Opening Hours: Open Daily: 8:00 - 20:00</span>
            </div>
        </div>
    </div>

    <!-- Main Navigation -->
    <nav class="container mx-auto px-4 ">
        <div class="flex justify-between items-center">
            <!-- Logo -->
<a href="<?php echo e(route('home')); ?>" class="flex items-center">
    <img 
        src="<?php echo e(asset('asset/images/logo.png')); ?>" 
        alt="ReliableSeva Logo" 
        class="h-20 w-auto"
    >
    <div class="text-gray-700 text-md md:text-3xl font-bold">Reliable Seva</div>
</a>




            <!-- Desktop Menu -->
            <div class="hidden md:flex items-center space-x-8">
                <a href="<?php echo e(route('home')); ?>" class="hidden text-gray-700 text-center hover:text-blue-600 font-medium transition uppercase <?php echo e(request()->routeIs('home') ? 'text-blue-600' : ''); ?>">Home</a>
                <a href="<?php echo e(route('home')); ?>" class="text-gray-700 text-center hover:text-blue-600 font-medium transition uppercase <?php echo e(request()->routeIs('home') ? 'text-blue-600' : ''); ?>">Home</a>

                <a href="<?php echo e(route('about')); ?>" class="text-gray-700 hover:text-blue-600 font-medium transition uppercase <?php echo e(request()->routeIs('about') ? 'text-blue-600' : ''); ?>">About Us</a>
                
                <a href="<?php echo e(route('services')); ?>" class="text-gray-700 hover:text-blue-600 font-medium transition uppercase <?php echo e(request()->routeIs('services') ? 'text-blue-600' : ''); ?>">Services</a>
                
                
                
                 <a href="<?php echo e(route('ourblog')); ?>" class="text-gray-700 hover:text-blue-600 font-medium transition uppercase <?php echo e(request()->routeIs('ourblog') ? 'text-blue-600' : ''); ?>">Blog</a>
                <a href="<?php echo e(route('contact')); ?>" class="bg-blue-600 text-white px-5 py-2 rounded-full font-medium hover:bg-blue-700 transition uppercase<?php echo e(request()->routeIs('contact') ? 'text-blue-600' : ''); ?>">Contact Us</a>
            </div>

            <!-- Mobile Menu Button -->
            <div class="md:hidden flex items-center">
                <button id="mobile-menu-btn" class="text-gray-700 hover:text-blue-600 focus:outline-none">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path></svg>
                </button>
            </div>
        </div>

        <!-- Mobile Menu -->
        <div id="mobile-menu" class="hidden md:hidden mt-4 pb-4 border-t border-gray-100">
            <a href="<?php echo e(route('home')); ?>" class="block py-2 text-gray-700 hover:text-blue-600 font-medium uppercase <?php echo e(request()->routeIs('home') ? 'text-blue-600' : ''); ?>">Home</a>
            <a href="<?php echo e(route('about')); ?>" class="block py-2 text-gray-700 hover:text-blue-600 font-medium uppercase <?php echo e(request()->routeIs('about') ? 'text-blue-600' : ''); ?>">About Us</a>
            
            <a href="<?php echo e(route('services')); ?>" class="block py-2 text-gray-700 hover:text-blue-600 font-medium uppercase <?php echo e(request()->routeIs('services') ? 'text-blue-600' : ''); ?>">Services</a>
            
            
            <a href="<?php echo e(route('contact')); ?>" class="block py-2 text-gray-700 hover:text-blue-600 font-medium uppercase <?php echo e(request()->routeIs('contact') ? 'text-blue-600' : ''); ?>">Contact Us</a>
              <a href="<?php echo e(route('ourblog')); ?>" class="block py-2 text-gray-700 hover:text-blue-600 font-medium uppercase <?php echo e(request()->routeIs('ourblog') ? 'text-blue-600' : ''); ?>">Blog</a>
            <a href="<?php echo e(route('contact')); ?>" class="inline-block mt-2 bg-blue-600 text-white px-5 py-2 rounded-full font-medium hover:bg-blue-700 transition">Get a Quote</a>
        </div>
    </nav>
</header><?php /**PATH D:\airvice\resources\views/partials/header.blade.php ENDPATH**/ ?>