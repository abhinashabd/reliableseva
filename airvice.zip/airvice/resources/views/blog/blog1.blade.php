@extends('layouts.app')

@section('title', 'Blog - Airvice')

@section('content')


@include('blog.herosection')

<section class="py-16">
        <div class="container mx-auto px-4">
            <div class="flex flex-col lg:flex-row gap-12">
                <!-- Main Blog Content -->
                <div class="lg:w-2/3">
                    <article class="blog-content">
                        <!-- Introduction -->
                        <p class="text-xl text-gray-700 font-medium mb-8">
                            As India continues its rapid urbanization, the construction industry faces both immense opportunities and significant challenges. Sustainable construction practices are no longer optional but essential for creating resilient, efficient, and environmentally responsible infrastructure.
                        </p>
                        
                        <h2 id="current-landscape">The Current Landscape of Construction in India</h2>
                        
                        <p>
                            India's construction sector is one of the largest in the world, contributing significantly to the nation's GDP. However, traditional construction methods have often prioritized speed and cost over environmental considerations. The industry accounts for approximately 22% of India's total greenhouse gas emissions and consumes vast amounts of natural resources.
                        </p>
                        
                        <div class="my-8">
                            <img src="https://images.unsplash.com/photo-1541976590-713941681591?w=1000" alt="Modern construction site" class="w-full rounded-2xl shadow-lg">
                            <p class="text-center text-gray-500 text-sm mt-2">Modern construction techniques are evolving to incorporate sustainable practices</p>
                        </div>
                        
                        <h2 id="sustainable-trends">Key Sustainable Construction Trends</h2>
                        
                        <h3>1. Green Building Materials</h3>
                        
                        <p>
                            The shift toward eco-friendly materials is gaining momentum across India. Traditional materials like concrete and steel are being supplemented or replaced with sustainable alternatives:
                        </p>
                        
                        <ul>
                            <li><strong>Bamboo:</strong> A rapidly renewable resource with excellent structural properties</li>
                            <li><strong>Recycled steel and plastic:</strong> Reducing waste and energy consumption</li>
                            <li><strong>Low-carbon concrete:</strong> Incorporating industrial byproducts like fly ash</li>
                            <li><strong>Rammed earth:</strong> Traditional technique with modern applications</li>
                        </ul>
                        
                        <h3>2. Energy-Efficient Design</h3>
                        
                        <p>
                            Building orientation, natural ventilation, and passive solar design are becoming standard practices in sustainable construction. These approaches significantly reduce energy consumption for heating, cooling, and lighting.
                        </p>
                        
                        <blockquote>
                            "Sustainable construction isn't just about materials—it's about designing buildings that work with their environment rather than against it."
                        </blockquote>
                        
                        <h3>3. Water Conservation Systems</h3>
                        
                        <p>
                            With water scarcity affecting many parts of India, sustainable construction emphasizes rainwater harvesting, greywater recycling, and efficient plumbing fixtures. These systems can reduce municipal water consumption by 30-50%.
                        </p>
                        
                        <div class="bg-blue-50 p-6 rounded-2xl my-8 border-l-4 border-[#0A2540]">
                            <h3 class="text-xl font-bold text-[#0A2540] mb-2">DC Indo Global's Sustainable Initiatives</h3>
                            <p class="text-gray-700">
                                At DC Indo Global, we've implemented comprehensive sustainability protocols across all our projects. Our recent commercial complex in Hyderabad achieved a 40% reduction in energy consumption and 50% water savings compared to conventional buildings of similar scale.
                            </p>
                        </div>
                        
                        <h2 id="government-initiatives">Government Initiatives and Policies</h2>
                        
                        <p>
                            The Indian government has launched several initiatives to promote sustainable construction:
                        </p>
                        
                        <ul>
                            <li><strong>Energy Conservation Building Code (ECBC):</strong> Mandatory efficiency standards for commercial buildings</li>
                            <li><strong>Green Rating for Integrated Habitat Assessment (GRIHA):</strong> National rating system for green buildings</li>
                            <li><strong>Leadership in Energy and Environmental Design (LEED):</strong> Internationally recognized certification promoted in India</li>
                            <li><strong>Smart Cities Mission:</strong> Incorporating sustainability in urban development</li>
                        </ul>
                        
                        <h2 id="challenges-opportunities">Challenges and Opportunities</h2>
                        
                        <p>
                            While the momentum for sustainable construction is building, several challenges remain:
                        </p>
                        
                        <ul>
                            <li>Higher upfront costs for green technologies</li>
                            <li>Limited awareness among smaller developers</li>
                            <li>Supply chain issues for sustainable materials</li>
                            <li>Need for skilled labor trained in green techniques</li>
                        </ul>
                        
                        <p>
                            However, these challenges present significant opportunities for innovation, job creation, and leadership in the global construction industry.
                        </p>
                        
                        <h2 id="road-ahead">The Road Ahead</h2>
                        
                        <p>
                            The future of sustainable construction in India looks promising. With technological advancements, growing environmental awareness, and supportive policies, we're witnessing a paradigm shift in how buildings are designed, constructed, and operated.
                        </p>
                        
                        <p>
                            At DC Indo Global, we're committed to being at the forefront of this transformation, developing innovative solutions that balance economic growth with environmental responsibility.
                        </p>
                        
                        <!-- Tags -->
                        <div class="mt-12 pt-8 border-t border-gray-200">
                            <div class="flex flex-wrap gap-2">
                                <span class="tag">Sustainable Construction</span>
                                <span class="tag">Green Building</span>
                                <span class="tag">India</span>
                                <span class="tag">Eco-friendly Materials</span>
                                <span class="tag">Energy Efficiency</span>
                            </div>
                        </div>
                    </article>
                    
                    <!-- Author Bio -->
                    <div class="card p-8 mt-12 bg-gray-50">
                        <div class="flex flex-col md:flex-row items-center md:items-start">
                            <div class="flex-shrink-0 mb-4 md:mb-0 md:mr-6">
                                <div class="w-20 h-20 bg-[#0A2540] rounded-full flex items-center justify-center text-white text-xl font-bold">
                                    AS
                                </div>
                            </div>
                            <div>
                                <h3 class="text-xl font-bold text-[#0A2540] mb-2">About the Author</h3>
                                <p class="text-gray-700 mb-4">
                                    Arun Sharma is the Head of Sustainability at DC Indo Global with over 15 years of experience in green building design and implementation. He has led numerous award-winning sustainable construction projects across India and serves on several national committees for environmental building standards.
                                </p>
                                <div class="flex space-x-4">
                                    <a href="#" class="text-[#0A2540] hover:text-[#D4AF37] transition-colors">
                                        <i data-lucide="linkedin" class="w-5 h-5"></i>
                                    </a>
                                    <a href="#" class="text-[#0A2540] hover:text-[#D4AF37] transition-colors">
                                        <i data-lucide="twitter" class="w-5 h-5"></i>
                                    </a>
                                    <a href="#" class="text-[#0A2540] hover:text-[#D4AF37] transition-colors">
                                        <i data-lucide="mail" class="w-5 h-5"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Share Section -->
                    <div class="mt-12 pt-8 border-t border-gray-200">
                        <div class="flex flex-col sm:flex-row items-center justify-between">
                            <h3 class="text-lg font-bold text-[#0A2540] mb-4 sm:mb-0">Share this article</h3>
                            <div class="flex space-x-3">
                                <a href="#" class="share-btn bg-[#3b5998] text-white">
                                    <i data-lucide="facebook" class="w-4 h-4"></i>
                                </a>
                                <a href="#" class="share-btn bg-[#1da1f2] text-white">
                                    <i data-lucide="twitter" class="w-4 h-4"></i>
                                </a>
                                <a href="#" class="share-btn bg-[#0077b5] text-white">
                                    <i data-lucide="linkedin" class="w-4 h-4"></i>
                                </a>
                                <a href="#" class="share-btn bg-[#25d366] text-white">
                                    <i data-lucide="message-circle" class="w-4 h-4"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Navigation Between Posts -->
                    <div class="flex flex-col sm:flex-row justify-between mt-12 pt-8 border-t border-gray-200">
                        <a href="#" class="group flex items-center mb-4 sm:mb-0">
                            <i data-lucide="arrow-left" class="w-5 h-5 mr-2 text-[#0A2540] group-hover:text-[#D4AF37] transition-colors"></i>
                            <div>
                                <p class="text-sm text-gray-500">Previous Article</p>
                                <p class="text-[#0A2540] font-medium group-hover:text-[#D4AF37] transition-colors">Innovations in Pre-Cast Concrete Technology</p>
                            </div>
                        </a>
                        <a href="#" class="group flex items-center text-right sm:text-left ml-auto">
                            <div>
                                <p class="text-sm text-gray-500">Next Article</p>
                                <p class="text-[#0A2540] font-medium group-hover:text-[#D4AF37] transition-colors">Safety First: Implementing New Protocols</p>
                            </div>
                            <i data-lucide="arrow-right" class="w-5 h-5 ml-2 text-[#0A2540] group-hover:text-[#D4AF37] transition-colors"></i>
                        </a>
                    </div>
                </div>
                
                <!-- Sidebar -->
                <div class="lg:w-1/3">
                    <!-- Table of Contents -->
                    <div class="card p-6 bg-white mb-8 sticky top-8">
                        <h3 class="text-xl font-bold text-[#0A2540] mb-4">Table of Contents</h3>
                        <ul class="space-y-2">
                            <li><a href="#current-landscape" class="text-gray-600 hover:text-[#0A2540] transition-colors flex items-start">
                                <i data-lucide="chevron-right" class="w-4 h-4 mt-0.5 mr-2 text-[#D4AF37] flex-shrink-0"></i>
                                <span>The Current Landscape</span>
                            </a></li>
                            <li><a href="#sustainable-trends" class="text-gray-600 hover:text-[#0A2540] transition-colors flex items-start">
                                <i data-lucide="chevron-right" class="w-4 h-4 mt-0.5 mr-2 text-[#D4AF37] flex-shrink-0"></i>
                                <span>Sustainable Construction Trends</span>
                            </a></li>
                            <li><a href="#government-initiatives" class="text-gray-600 hover:text-[#0A2540] transition-colors flex items-start">
                                <i data-lucide="chevron-right" class="w-4 h-4 mt-0.5 mr-2 text-[#D4AF37] flex-shrink-0"></i>
                                <span>Government Initiatives</span>
                            </a></li>
                            <li><a href="#challenges-opportunities" class="text-gray-600 hover:text-[#0A2540] transition-colors flex items-start">
                                <i data-lucide="chevron-right" class="w-4 h-4 mt-0.5 mr-2 text-[#D4AF37] flex-shrink-0"></i>
                                <span>Challenges &amp; Opportunities</span>
                            </a></li>
                            <li><a href="#road-ahead" class="text-gray-600 hover:text-[#0A2540] transition-colors flex items-start">
                                <i data-lucide="chevron-right" class="w-4 h-4 mt-0.5 mr-2 text-[#D4AF37] flex-shrink-0"></i>
                                <span>The Road Ahead</span>
                            </a></li>
                        </ul>
                    </div>
                    
                    <!-- Related Posts -->
                    <div class="card p-6 bg-white mb-8">
                        <h3 class="text-xl font-bold text-[#0A2540] mb-4">Related Articles</h3>
                        <div class="space-y-4">
                            <div class="flex items-start">
                                <img src="https://images.unsplash.com/photo-1581094794329-c8112a89af12?w=200" alt="Safety protocols" class="w-16 h-16 object-cover rounded-lg mr-4 flex-shrink-0">
                                <div>
                                    <a href="#" class="text-[#0A2540] font-medium hover:text-[#D4AF37] transition-colors line-clamp-2">Safety First: Implementing New Protocols at DC Indo Global</a>
                                    <p class="text-gray-500 text-sm mt-1">May 28, 2024</p>
                                </div>
                            </div>
                            <div class="flex items-start">
                                <img src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=200" alt="Green materials" class="w-16 h-16 object-cover rounded-lg mr-4 flex-shrink-0">
                                <div>
                                    <a href="#" class="text-[#0A2540] font-medium hover:text-[#D4AF37] transition-colors line-clamp-2">Green Building Materials: What's Next for Sustainable Construction</a>
                                    <p class="text-gray-500 text-sm mt-1">May 5, 2024</p>
                                </div>
                            </div>
                            <div class="flex items-start">
                                <img src="https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=200" alt="AI in construction" class="w-16 h-16 object-cover rounded-lg mr-4 flex-shrink-0">
                                <div>
                                    <a href="#" class="text-[#0A2540] font-medium hover:text-[#D4AF37] transition-colors line-clamp-2">The Role of AI in Modern Construction Management</a>
                                    <p class="text-gray-500 text-sm mt-1">April 10, 2024</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Newsletter Signup -->
                    <div class="card p-6 bg-[#0A2540] text-white">
                        <h3 class="text-xl font-bold mb-4">Stay Updated</h3>
                        <p class="mb-4 text-gray-300">Get the latest articles and industry insights delivered to your inbox.</p>
                        <form class="space-y-3">
                            <input type="email" placeholder="Your email address" class="w-full px-4 py-2 rounded-lg text-gray-800">
                            <button type="submit" class="w-full bg-[#D4AF37] text-white py-2 rounded-lg font-medium hover:bg-[#c19b2a] transition-colors">Subscribe</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>





@endsection